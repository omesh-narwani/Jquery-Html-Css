$(document).ready(function () {
	//Checkbox Adding Color 
	$(".ColorBox").each(function(index, el) {
		$ColorDiv = $(this).attr("data-color");
		$(this).css('background', '#'+$ColorDiv);	
	});
	if ( $( ".InputCheckbox" ).length ) {
		  $('.InputCheckbox input').iCheck({
		    checkboxClass: 'icheckbox_minimal-red',
		    radioClass: 'iradio_minimal-red',
		    increaseArea: '20%' // optional
		  });
	}
 	
	
	// Header Swiper Function 

	 var swiper = new Swiper('.swiper-container', {
      slidesPerView: 'auto',
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
    });
	 // Swiper For Testimonials
	 // swiperTestimonials.allowTouchMove = true

	  swiperTestimonials = new Swiper('.swiper-container-testimonials', {
  			allowTouchMove: false,
	      pagination: {
	        el: '.swiper-pagination',
	        clickable: true,
	      },
    });
	  if($(window).width() < 1199) {
	 	swiperTestimonials.allowTouchMove = true;
	 }
	 // Services Swiper 
	  swiperTwo = new Swiper('.swiper-container-two', {
	  	slidesPerView: 'auto',
	    spaceBetween: 30,
	    navigation: {
	        nextEl: '.Serv-Next',
	        prevEl: '.Serv-Prev',
	      },
	    });
	   // Services Swiper 
	  swiperTwo = new Swiper('.swiper-container-pricing', {
	  	slidesPerView: 'auto',
	    spaceBetween: 30,
	    navigation: {
	        nextEl: '.Pricing-Next',
	        prevEl: '.Pricing-Prev',
	      },
	    });
	  // Swipper For Promises
	  swiperPromise = new Swiper('.swiper-container-promise', {
	  	slidesPerView: 'auto',
	    spaceBetween: 10,
	    navigation: {
	        nextEl: '.Pro-Next',
	        prevEl: '.Pro-Prev',
	      },
	    });
	  // Images Light Boxes JS
	   lightbox.option({
	      'resizeDuration': 200,
	      'wrapAround': true,
	      'showImageNumberLabel':false,
	    });
	   // Testimonials Section Image
	   $(".LeftTestimonialSec figure").each(function (index) {
	   		$Top = $(this).attr("data-top"); 
	   		$left = $(this).attr("data-left");  
	   		$Right = $(this).attr("data-right");
	   		$bottom = $(this).attr("data-bottom");
	   		$(this).css({
	   			top: $Top+'px',
	   			left: $left+'px',
	   			right: $Right+'px',
	   			bottom : $bottom+'px',
	   		});
	   });

});
// Testimonial Change Images and Run Swiper
$(document).on("click",".TestimonialsSection .MainParentSec .LeftTestimonialSec figure .Unact ",function () {
	$ImngSources = $(this).attr("src");
	$index = $(this).parent('figure').index();
	$(this).parent("figure").parent('.LeftTestimonialSec').find("img.Active").attr("src",$ImngSources)
	$(this).parent("figure").parent('.LeftTestimonialSec').find("img.Active").attr("src",$ImngSources);
	swiperTestimonials.slideTo($index);
});
// Swiper pagination function And change Images Of Swiper
$(document).on("click",".swiper-container-testimonials .swiper-pagination span",function () {
	$getIndexd = $(this).index();
	$srcVal = $(".TestimonialsSection .MainParentSec .LeftTestimonialSec figure .Unact").eq($getIndexd).attr("src");
	$(".TestimonialsSection .MainParentSec .LeftTestimonialSec figure .Active").attr("src",$srcVal);

});

// Gallery Swiper
function ForMultiPleGallerySwiper($VarCahnge,$getClass) {
	 $VarCahnge = new Swiper('.'+$getClass, {
	      slidesPerView: 4,
	      slidesPerColumn: 2,
	      spaceBetween: 0,
	      pagination: {
	        el: '.swiper-pagination',
	        clickable: true,
	      },
	       navigation: {
	        nextEl: '.swiper-button-next',
	        prevEl: '.swiper-button-prev',
	      },
	      breakpoints: {
	        1024: {
	          slidesPerView: 4,
	        },
	        992: {
	          slidesPerView: 4,
	        },
	        991: {
	          slidesPerView: 3,
	        },
	        768: {
	          slidesPerView: 3,
	        },
	        640: {
	          slidesPerView: 1,
	        },
	        320: {
	          slidesPerView: 1,
	        }
	      },
	       onReachEnd: function(swiper) {
		      //callback function code here
		      console.log("fafa");
		    }   
	    });
}
ForMultiPleGallerySwiper('SwipeOne','swiper-container-gallery-Logo');
ForMultiPleGallerySwiper('SwipeTwo','swiper-container-gallery-WebSite');
ForMultiPleGallerySwiper('SwipeThree','swiper-container-gallery-Branding');

// Update Swiper After Tabs Shifting
$(document).on("click",".TabIngSection ul li ",function() {
	$(this).delay(150).queue(function() {
	    ForMultiPleGallerySwiper('SwipeOne','swiper-container-gallery-Logo');
		ForMultiPleGallerySwiper('SwipeTwo','swiper-container-gallery-WebSite');
		ForMultiPleGallerySwiper('SwipeThree','swiper-container-gallery-Branding');
	  });
});

// packages Btn Click and show package Details
$(document).on("click",".BtnPack a",function (event) {
	event.preventDefault();
	$parentDiv = $(this).parents(".DescriptionSec ");
	$parentDiv.find(".back").slideDown('linear');
});
// Slide Up Form Pack Colose package 
$(document).on("click",".CloseIcon",function (event) {
	event.preventDefault();
	$parentDiv = $(this).parents(".DescriptionSec ");
	$parentDiv.find(".back").slideUp('linear');
});
$(document).on("click",".SubmitBtn",function (event) {
	event.preventDefault();
});
$(document).on("mouseover",".navBarDeskTop .MainNavBar li a",function () {
	$Attr = $(this).attr("title");
	$(this).css('border-bottom', '3px solid #'+$Attr);
}).on("mouseleave",".navBarDeskTop .MainNavBar li a",function () {
	$(this).css('border-bottom', 'transparent');
});

// Get A Quote and Show Requet A Quote
$(document).on("click",".GetAQuote",function () {
	$(".OverFlow").fadeIn("linear",function () {
		$("body").css('overflow', 'hidden');
		$(".RequestAQuoteHeader").slideDown();
	});
});
$(document).on("click",".OverFlow",function () {
	$(".RequestAQuoteHeader").slideUp(function () {
		$("body").css('overflow', 'visible');
		$(".OverFlow").fadeOut();
	});
});
$(document).on("click",".ClsICons",function () {
	$(".RequestAQuoteHeader").slideUp(function () {
		$("body").css('overflow', 'visible');
		$(".OverFlow").fadeOut();
	});
});

$(document).on("click",".IconCover",function () {
	if($(this).hasClass('active')) {
		$(this).removeClass('active');
		$(".ResMenuStart").css('width', '0');
	} else {
		$(this).addClass('active');
		$(".ResMenuStart").css('width', '300px');
	}
});